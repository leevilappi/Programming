
package kierros3

object Filter {
  
  
  //Contains original created image
  private var originalImage: Image = new Image(View.fileName)   

  
  /*
   *  Method utilizes a filter that lightens image by using methond toLighten.
   */
  def lightness(factor: Float, img: Image) : Unit = {  
    var lightened = Vector.tabulate(img.width, img.height)(img.getColor(_, _).toLighten(factor))
    img.setImage(lightened)
  }

  /*
   *  Method utilizes a filter that inverts image by using methond toInvert.
   */
  def invert(img: Image) : Unit = {
    var inverted = Vector.tabulate(img.width, img.height)(img.getColor(_, _).toInvert)
    img.setImage(inverted)
  }
  
  
  /*
   *  Method utilizes a filter that makes the image grey by using method toGrey.
   */
  def grayscale(img: Image) : Unit = {
    var mrGrey = Vector.tabulate(img.width, img.height)(img.getColor(_, _).toGray)
    img.setImage(mrGrey)
  }
  
  /*
   *  Adjust[Color] methods adjusts the colors of a picture by changing the corresponding RGB-value.
   *  The method utilizes method adjustColor 
   */
  
  
  def adjustRed(amount: Int, img: Image) : Unit = {    
    var addRed = Vector.tabulate(img.width, img.height)(img.getColor(_, _).adjustColor(amount, "r"))
    img.setImage(addRed)
  }

  def adjustGreen(amount: Int, img: Image) : Unit = {
    var addColor = Vector.tabulate(img.width, img.height)(img.getColor(_, _).adjustColor(amount, "g"))
    img.setImage(addColor)
  }

  def adjustBlue(amount: Int, img: Image) : Unit = {
    
    var addColor = Vector.tabulate(img.width, img.height)(img.getColor(_, _).adjustColor(amount, "b"))
    img.setImage(addColor)
  }


  /*
   *  Method blur blurs the image with selected amount. 
   *  Blur is achieved by creating a filter that compares adjacent 
   *  pixels and then averages them out resulting in a blurry result.
   */
  def blur(amount: Int, image: Image) : Unit = {
    import scala.math._
    var seed: Float = 0
    
    if (amount % 2 == 0){
      seed = pow(pow(amount/2, 2) + pow(1 + amount/2, 2), -1).toFloat
      if(seed >= 1){
        seed = 1
      }
    }else {
      seed = pow(pow(amount,2), -1).toFloat
      if(seed >= 1){
        seed = 1
      }
    }
    
    var filter = getFilter(amount, seed)
    
    var newImage = Vector.tabulate(image.width, image.height)(multiplyWithFilter(_,_, image, filter))
   
    image.setImage(newImage)
    
  }
   
  /*
   *  Method sharpen sharpens the image with selected amount. 
   *  Sharpness is achieved by creating a filter that multiplies each
   *  pixel with a calculated multiplier.
   */
  def sharpen(amount: Int, image: Image) : Unit = {
    import scala.math._
    var seed: Float = -1
    var seedInMiddle: Float = 0
    var startValue = 1
    //matikkaa
    if(amount % 2 == 0){
      seedInMiddle = (2 * pow(amount, 2) - 2 * amount + 1).toFloat
    }else{
      seedInMiddle = (pow(amount, 2)).toFloat
    }
    
    var filter = getFilter(amount, seed)
    filter(amount/2)(amount/2) = seedInMiddle
    
    
    
    var newImage = Vector.tabulate(image.width, image.height)(multiplyWithFilter(_,_, image, filter))
   
    image.setImage(newImage)
  }
  
  /*
   *  Method creates an filter with a selected seed value that is later used for multiplying pixels
   *  in an image. Creates diffent filters whether amount is divisible by 2. 
   */
  private def getFilter(amount: Int, seed: Float) : Array[Array[Float]] ={
    import math._
    
    
    if(amount % 2 == 0){
      var filterArray = Array.fill(amount+1, amount+1)(seed)
  
      var k = amount/ 2
      
      for(x <- 0 to amount ; y <- 0 to amount){
        if(y < k - x || y < abs(k-x)|| x < abs(k-y) || x + y > 3*k ){
          filterArray(x)(y) = 0
        }
      }
      filterArray
    }else{
      Array.fill(amount, amount)(seed)
    }
  }

  /*
   *  Method is used by filters blur and sharpen. Its output is a new color that is calculated
   *  by the given filter parameter. 
   */
  
  private def multiplyWithFilter(x: Int, y: Int, image: Image, filter: Array[Array[Float]]) : Color = {
  
   var a = image.getAlpha(x, y)
   var r: Float = 0
   var g: Float = 0
   var b: Float = 0

   // Methods xBorderIsOver and yBorderIsOver help method multiplyWithFilter to determine
   // whether the filter is about to go over the image. 
   def xBorderIsOver = {
     if(x + filter.length/2 >= image.width || x - filter.length/2 < 0){
       true
     }else{
       false
     }
   }
   
   def yBorderIsOver ={
     if(y + filter.length/2 >= image.height || y - filter.length/2 < 0) true else false
   }
   
    if( xBorderIsOver || yBorderIsOver){ //If over image border, it gets original color of the pixel
      
      image.getColor(x, y)      
      
    }else {
      //Otherwise changes the state of the pixel by multiplying it with filters value.
      for(i <- 0 until filter.length; j <- 0 until filter.length){
        
        r += image.getRed  (x + i - filter.length / 2, y + j - filter.length /2) * filter(i)(j)
        g += image.getGreen(x + i - filter.length / 2, y + j - filter.length /2) * filter(i)(j)
        b += image.getBlue(x + i - filter.length / 2, y + j - filter.length /2) * filter(i)(j)
        
      }
      new Color(a,r.toInt,g.toInt,b.toInt)
    }
      
  }

}




