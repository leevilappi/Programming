package kierros3

/**
 * 
 */

object Color {
  
  
  /*
   *  Method clamp prevents program breaking actions by limiting an integer to 255,
   *  for that is the maximum for RGB-colors color value. If input is over 255 it returns 255,
   *  or if input is less than zero returns zero. Otherwise returns input.
   */
   def clamp(i : Int) : Int = if (i >= 255) 255 else if (i <= 0) 0 else i
   
}

class Color(var a: Int, var r: Int, var g: Int, var b: Int, var argb : Int) {
  
  /**
   * @constructor
   * @param a
   * @param r
   * @param g
   * @param b
   */
  
  
  def this(a: Int, r: Int, g: Int, b: Int) {
    this(Color.clamp(a),
         Color.clamp(r),
         Color.clamp(g),
         Color.clamp(b),
         -1)
    this.setInt
  }
  
  /**
   * 
   * @constructor
   * @paaram argb
   */
  def this(argb: Int) {
    this(-1, -1, -1, -1, argb)
    this.setComponents()
  }
  
  
  /**
   *  Method is a binary level operation. Method creates an 32-bit integer
   *  which contains information regarding a,r,g,b-channels and stores it 
   *  into an argb - variable.
   */
  private def setInt() : Unit = {
    argb = a << 24 | r << 16 | g << 8 | b
  }
  
  /**
   *  Method is a binary level operation. Method separets argb-variables information
   *  and separates it to different channels. 
   */
  private def setComponents() : Unit = {
    
    a = argb >>> 24 
    r = argb >>> 16 & 0xff
    g = argb >>> 8  & 0xff
    b = argb & 0xff
    
  }
  
  /*
   *  Method toGray changes each pixel's color towards gray. Grayness is
   *  achieved by calculating the average of each color(r,g,b) of the pixel and
   *  giving the value to each color of the pixel.
   */
  
  def toGray = {
    val grey = (r + g + b) / 3
    r = grey
    b = grey
    g = grey
    
    new Color(a,r,g,b)
  }
  
  /*
   *  Method toInvert changes each pixel's color by inverting its color.
   */
  
 def toInvert = {
   
   r = 255 - r
   g = 255 - g
   b = 255 - b
   new Color(a,r,g,b)
 }
 
 /*
  *  Method toLighten changes each pixel's color by increasing its lightness.
  *  Lightness is achieved with a multiplier that is below one. Vice versa, 
  *  darkness is achieved with a multiplier that is over one.
  */
 
 def toLighten(factor: Float) = {
   r = (r * factor).toInt
   g = (g * factor).toInt
   b = (b * factor).toInt
   
   new Color(a,r,g,b)
   
 }
 
 /*
  * Method adjustColor adjusts pixel's selected color by increasing 
  * it with selected amount.
  */
 
 def adjustColor(amount: Int, c: String) = { 

   c match {
     case "r" => this.r += amount; r
     case "g" => this.g += amount; g
     case "b" => this.b += amount; b
   }
   
   new Color(this.a,this.r,this.g,this.b)
   
 }
 
}
