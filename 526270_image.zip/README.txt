Ohjelmointistudio 1 - Leevi Lappi

Teht�v� oli todella monipuolinen ja sen mukana tuli haastetta. Bittioperaatiot avautui oikeastaan vain assareiden avulla, eli jatkossa mahdollisesti linkki vaikka johonkin opetusvideoon? Itselleni aukesi parhaiten konsultoimalla kurssiassistenttia.

Itselleni ylivoimaisesti haastavin oli kohta oli getFilter metodin filter-kuvioiden miettiminen, joka tuntui aika matemaattisesti/geometrisesti vaativalta. 

Lis�teht�v� oli erinomainen! Se oli sopivan haastava, ett� tiedon etsiminen netist� oli ennemmin nautinnollisen raivostuttavaa kuin pelk�st��n tuskastuttavaa. 