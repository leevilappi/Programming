
////////////////// NOTE TO STUDENTS //////////////////////////
// For the purposes of our course, it's not necessary    
// that you understand or even look at the code in this file. 
//////////////////////////////////////////////////////////////

package object o1 {

  def soita(biisi: String) = {
    sound.play(biisi)
  }

}